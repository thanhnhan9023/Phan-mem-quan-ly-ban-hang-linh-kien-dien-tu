package com.example.quanlythietbidientu2.Model;

public class Chitietdondathang {


    private String MaDH,MaHH;
    private  int Soluong;
    private float Giaban;
    private  double Thanhtien;

    public Chitietdondathang() {
    }

    public String getMaDH() {
        return MaDH;
    }

    public void setMaDH(String maDH) {
        MaDH = maDH;
    }

    public String getMaHH() {
        return MaHH;
    }

    public void setMaHH(String maHH) {
        MaHH = maHH;
    }

    public int getSoluong() {
        return Soluong;
    }

    public void setSoluong(int soluong) {
        Soluong = soluong;
    }

    public float getGiaban() {
        return Giaban;
    }

    public void setGiaban(float giaban) {
        Giaban = giaban;
    }

    public double getThanhtien() {
        return Thanhtien;
    }

    public void setThanhtien(double thanhtien) {
        Thanhtien = thanhtien;
    }
}
