package com.example.quanlythietbidientu2.Model;

public class LoaiProduct {
//    private  String ID,Name,Link;
//
//    public LoaiProduct() {
//    }
//
//    public String getID() {
//        return ID;
//    }
//
//    public void setID(String ID) {
//        this.ID = ID;
//    }
//
//    public String getName() {
//        return Name;
//    }
//
//    public void setName(String name) {
//        Name = name;
//    }
//
//    public String getLink() {
//        return Link;
//    }
//
//    public void setLink(String link) {
//        Link = link;
//    }
    private  String MaLoai,TenLoai,Linkloaihang,TinhTrangHang;

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String maLoai) {
        MaLoai = maLoai;
    }

    public String getTenLoai() {
        return TenLoai;
    }

    public void setTenLoai(String tenLoai) {
        TenLoai = tenLoai;
    }

    public String getLinkloaihang() {
        return Linkloaihang;
    }

    public void setLinkloaihang(String linkloaihang) {
        Linkloaihang = linkloaihang;
    }

    public String getTinhTrangHang() {
        return TinhTrangHang;
    }

    public void setTinhTrangHang(String tinhTrangHang) {
        TinhTrangHang = tinhTrangHang;
    }
}
