package com.example.quanlythietbidientu2.InterFace;

import android.view.View;

public interface ItemClickListnear {
    void Onclick(View v);
}
