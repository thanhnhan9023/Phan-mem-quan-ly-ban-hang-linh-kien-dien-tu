package com.example.quanlythietbidientu2.Model;

public class SanPham {

    //    private String ID_SP,ID;
//    private String NameSP,LinkSP,MoTa;
//    private  String  Price;
//
//    public String getID_SP() {
//        return ID_SP;
//    }
//
//    public void setID_SP(String ID_SP) {
//        this.ID_SP = ID_SP;
//    }
//
//    public String getID() {
//        return ID;
//    }
//
//    public void setID(String ID) {
//        this.ID = ID;
//    }
//
//    public String getPrice() {
//        return Price;
//    }
//
//    public void setPrice(String price) {
//        Price = price;
//    }
//
//    public String getNameSP() {
//        return NameSP;
//    }
//
//    public void setNameSP(String nameSP) {
//        NameSP = nameSP;
//    }
//
//    public String getLinkSP() {
//        return LinkSP;
//    }
//
//    public void setLinkSP(String linkSP) {
//        LinkSP = linkSP;
//    }
//
//    public String getMoTa() {
//        return MoTa;
//    }
//
//    public void setMoTa(String moTa) {
//        MoTa = moTa;
//    }
    private String MaHH, MaLoai, Duongdan, TenHH, DonViTinh, MoTa, Giabanle;

    public SanPham() {
    }

    public String getMaHH() {
        return MaHH;
    }

    public void setMaHH(String maHH) {
        MaHH = maHH;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String maLoai) {
        MaLoai = maLoai;
    }

    public String getDuongdan() {
        return Duongdan;
    }

    public void setDuongdan(String duongdan) {
        Duongdan = duongdan;
    }

    public String getTenHH() {
        return TenHH;
    }

    public void setTenHH(String tenHH) {
        TenHH = tenHH;
    }

    public String getDonViTinh() {
        return DonViTinh;
    }

    public void setDonViTinh(String donViTinh) {
        DonViTinh = donViTinh;
    }

    public String getMoTa() {
        return MoTa;
    }

    public void setMoTa(String moTa) {
        MoTa = moTa;
    }

    public String getGiabanle() {
        return Giabanle;
    }

    public void setGiabanle(String giabanle) {
        Giabanle = giabanle;
    }


}
